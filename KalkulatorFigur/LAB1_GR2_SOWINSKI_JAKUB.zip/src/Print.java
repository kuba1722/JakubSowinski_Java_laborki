public interface Print {
    public void print();
}
